Compilar: make
Utilizar: java TEG2 caminho/para/grafo.txt
